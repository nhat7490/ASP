create procedure CalculateDistanceForMember(IN userId int, IN pageOf int, IN size int)
  BEGIN

DECLARE theta			DOUBLE;
DECLARE dist 			DOUBLE;
DECLARE lon1 			DOUBLE;
DECLARE lat1 			DOUBLE;
DECLARE lon2 			DOUBLE;
DECLARE lat2 			DOUBLE;
DECLARE startIndex		INT;
DECLARE post_id_temp	INT;
DECLARE done 			INT DEFAULT FALSE;
DECLARE cur1 			CURSOR FOR SELECT longtitude, lattitude FROM CalDis;
DECLARE cur2 			CURSOR FOR SELECT post_id FROM CalDis;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

DROP TABLE IF EXISTS CalDis;
DROP TABLE IF EXISTS PostTemp;

SET lon1 = 
	(	SELECT	longtitude
		FROM 	tb_post AS p
		WHERE 	p.user_id = userId
			AND p.type_id = 1);

SET lat1 = 
	(	SELECT 	lattitude
		FROM 	tb_post AS p
		WHERE 	p.user_id = userId
			AND p.type_id = 1);    

CREATE TEMPORARY TABLE CalDis
SELECT	* 
FROM 	tb_post 
WHERE 	tb_post.room_id 
	IN
    (	SELECT	room_id
		FROM 	tb_room AS r
		WHERE 	r.district_id = 
			(	SELECT	district_id
				FROM 	tb_room AS r
				WHERE 	r.room_id = 
					(	SELECT	room_id
						FROM 	tb_post AS p
						WHERE 	p.user_id = userId
							AND p.type_id = 1)))
	AND	tb_post.user_id <> userId;
    
ALTER TABLE CalDis
ADD PRIMARY KEY (post_id),
ADD COLUMN distance FLOAT;

OPEN cur1;  
OPEN cur2;
read_loop: LOOP
	FETCH cur1 INTO lon2, lat2;    
	FETCH cur2 INTO post_id_temp;
	IF done THEN
		LEAVE read_loop;    
	ELSE
		SET theta = lon1 - lon2;
		SET dist = sin(lat1 * PI() / 180.0) * sin(lat2 * PI() / 180.0) + cos(lat1 * PI() / 180.0) * cos(lat2 * PI() / 180.0) * cos(theta * PI() / 180.0);
		SET dist = acos(dist);
		SET dist = dist * 180 / PI();
		SET dist = dist * 60 * 1.1515 * 1.609344;		
		UPDATE	CalDis
		SET		distance = dist
		WHERE	post_id = post_id_temp;
	END IF;
END LOOP;
CLOSE cur1; 
CLOSE cur2; 

CREATE TEMPORARY TABLE PostTemp
SELECT		* 
FROM 		CalDis
ORDER BY	distance;

ALTER TABLE PostTemp
DROP COLUMN distance;
        
SET startIndex = (pageOf - 1) * size;

SELECT	*
FROM	PostTemp
LIMIT	startIndex, size;
END;

